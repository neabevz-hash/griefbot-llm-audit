# harness — общий стенд прогонов

Пакет `llmaudit`: многоходовые прогоны через OpenRouter, слепой судья через `claude -p`, статистика согласия. На нём стоят гриф-боты, Т3, Т1 и Т5.

## Установка

```bash
python -m venv .venv
.venv/Scripts/python -m pip install -e harness
```

Ключи лежат в `.env` в корне репозитория (вне git):

- `OPENROUTER_API_KEY` — для прогонов;
- `CLAUDE_CODE_OAUTH_TOKEN` — для судьи. Токен выдаёт `claude setup-token`, он работает по подписке Max. Сессию десктопного приложения дочерние процессы использовать не могут.

## Модули

| Модуль | Что делает |
| --- | --- |
| `llmaudit.runner` | Гоняет сценарии: фиксированные реплики пользователя, модель видит свои прошлые ответы. Можно продолжить с места остановки. Для каждого вызова пишет провайдера, модель, токены, стоимость, задержку и причину остановки. |
| `llmaudit.openrouter` | Асинхронный клиент: повторы при сбоях, явный кэш для Anthropic и Alibaba. Пустой ответ считает сбоем, `content_filter` — исходом. |
| `llmaudit.judge` | Слепой судья: отдельный процесс `claude -p` на каждый диалог, свой системный промпт, без инструментов и без CLAUDE.md, JSON-схема, случайный порядок. |
| `llmaudit.blind` | Перед оценкой маскирует названия моделей и компаний в ответах. |
| `llmaudit.agreement` | Каппа Коэна, AC1 Гвета, PABAK, бутстрэп-интервалы. |

## Формат сценария (spec)

Одна строка JSONL — один диалог:

```json
{"conv_id": "gb.P01.app.early.r1.sonnet55",
 "model": "anthropic/claude-sonnet-5.5",
 "provider": {"only": ["anthropic"], "allow_fallbacks": false},
 "params": {"max_tokens": 8192},
 "cache": true,
 "system": "…",
 "turns": ["…", "…"],
 "labels": ["T1_open", "T2_memory"],
 "meta": {"persona": "P01", "deployment": "app", "time": "early"}}
```

Сценарии собирает скрипт статьи, например `papers/grief-bots/build_specs.py`.

## Запуск

```bash
.venv/Scripts/python -m llmaudit.runner --specs papers/<статья>/data/<run>/specs.jsonl \
    --out papers/<статья>/data/<run>/transcripts.jsonl --per-model 4 --max-cost 12
```

Технические сбои пишутся в `transcripts.jsonl.errors.jsonl`. При повторном запуске упавшие диалоги перезапускаются с начала, готовые пропускаются.

## Правила

- Провайдера закрепляем за разработчиком модели (`provider.only`, без fallback). Без этого OpenRouter на каждом ходу отдаёт запрос новому хосту с другой квантизацией.
- Параметры по умолчанию: температуру и reasoning не трогаем, `max_tokens` = 8192 только как предохранитель.
- Порядок прогона перемешан с фиксированным seed.
- Пилоты гоняем на моделях вне панели, чтобы не видеть данных панели до преррегистрации.
