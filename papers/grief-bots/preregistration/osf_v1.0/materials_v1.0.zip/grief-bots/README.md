# Гриф-боты и пролонгированное горе

**Отличие одной фразой.** Первый многомодельный многоходовый факторный аудит того, как LLM играют умершего близкого. Сравниваем просьбу пользователя, гриф-бот оператора и контроль без персоны, ранний и поздний срок утраты. Ответы кодируем по кодбуку, привязанному к критериям ПРГ, к различению внутренней и внешней связи (Field) и к C-SSRS. Судью проверяем по людям отдельно для каждой модели.

Конкурентов с таким дизайном нет; проверено 2026-10-04, см. `literature/`. Ближе всего: Manning et al. 2026 (DIS) — качественное исследование на 16 пользователях с одной моделью; Van Kempen et al. 2025 — один запрос «притворись им» к двум системам; Kim et al. 2026 — одна речевая модель без персоны.

**Журнал:** Death Studies, запасной — OMEGA.

## Статус

| Шаг | Состояние |
| --- | --- |
| Скан конкурентов | готово: `literature/scan_*.md` |
| Протокол | v1.0 заморожен 2026-10-05, тег `grief-bots-prereg-v1.0` |
| Стенд | готово: `harness/llmaudit` |
| Пилот | 96 диалогов на 4 моделях вне панели, $0.82 |
| Кодбук | v1.0 заморожен; тест формы на трёх тестировщиках — 96% совпадения судьи с их большинством |
| Судья на пилоте | готово: Opus 5.5 разметил 96/96, `data/pilot/judgments.jsonl`, анализ — `data/pilot/results.md` |
| Тренировка разметчиков | форма `human/forms/coding_form_pilot.html` (9 диалогов), инструкция `human/ИНСТРУКЦИЯ_разметчику.md` |
| Эксперт с кафедры | по желанию: письмо `human/письмо_преподавателю.md` |
| Преррегистрация OSF | пакет готов: `preregistration/osf_v1.0/`; шаги — `preregistration/КАК_ЗАРЕГИСТРИРОВАТЬ.md`; публикует автор |
| Основной прогон | 576 + 48 диалогов, ≈ $15–16; запускать только после регистрации |

## Файлы

| Путь | Что |
| --- | --- |
| `protocol.md` | протокол и текст преррегистрации, с проверенными ссылками |
| `codebook.md` | кодбук: одинаковый для судьи и для людей |
| `scenarios/personas.yaml` | 12 синтетических персон |
| `scenarios/script.yaml` | 9 ходов, три режима, два срока |
| `config/*.yaml` | пилот и основной прогон |
| `build_specs.py` | сборка сценариев (`--preview P03 app late` показывает диалог) |
| `judge_run.py` | судья: `claude -p` (основной) или API (второй) |
| `judge/schema.json`, `judge/make_schema.py` | JSON-схема кодов |
| `analysis/outcomes.py` | исходы P1–P5 и вторичные |
| `human/` | выборка, офлайн-форма разметки, отчёт о согласии |
| `data/pilot/`, `data/main/` | сценарии, транскрипты, коды |
| `literature/` | сканы: CS/HCI, психология, клиника и методы, контекст |

## Команды

```bash
# предпросмотр одного диалога
.venv/Scripts/python papers/grief-bots/build_specs.py config/main.yaml --preview P06 app early
# прогон (после регистрации)
.venv/Scripts/python -m llmaudit.runner --specs papers/grief-bots/data/main/specs.jsonl --out papers/grief-bots/data/main/transcripts.jsonl --per-model 4 --max-cost 16
# судья
.venv/Scripts/python papers/grief-bots/judge_run.py main --concurrency 4
# исходы
.venv/Scripts/python papers/grief-bots/analysis/outcomes.py main --summary
```
